package com.persistent.apps.day.eight;

import java.util.List;

@FunctionalInterface
interface  Validator{
    public abstract  boolean  isEligible(int age);
}
public class AppFour {
    private static void findOutEligibleAndInEligibleDetails(List<Integer> ageList,Validator validator){
        int eligibleCnt=0;
        int inEligibleCnt=0;
        for(Integer age:ageList){
            if(validator.isEligible(age)){
                eligibleCnt++;
            }else{
                inEligibleCnt++;
            }
        }
        System.out.println("Eligible count is:"+eligibleCnt);
        System.out.println("InEligible count is:"+inEligibleCnt);
    }

    public static void main(String[] args) {
        List<Integer> ageList= List.of(11,19,22,33,55,67,99,12,14);
        findOutEligibleAndInEligibleDetails(ageList,age ->(age>=18 && age<=120)?true:false);
    }
}
