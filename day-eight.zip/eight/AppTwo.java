//program to implement hashmap for storing student and course details
package com.persistent.apps.day.eight;

import java.util.*;

public class AppTwo {

    private static void makeAnEntry(Map<String,String> map,String sname,String scourse){
    map.put(sname,scourse);
    }
    private static void findAnEntryByStudentName(Map<String,String> map,String name){

        if(map.containsKey(name)){
            System.out.println("student entry found for "+name);
        }else{
            System.out.println("student entry not found for "+name);
        }


    }
    private static void findAnEntryByCourse(Map<String,String> map,String course){
        if(map.containsValue(course)){
            System.out.println("student entry found for "+course);
        }else{
            System.out.println("student entry not found for "+course);
        }
    }

    private static void removeAnEntryByStudentName(Map<String,String> map,String name){

                if(map.remove(name)!=null){
                    System.out.println("student entry removed");
                }else{
                    System.out.println("student entry not found to remove");
                }
    }

    private static void removeAnEntryByCourse(Map<String,String> map,String course){

        List<String> nameList=new ArrayList<>();

        if(map.containsValue(course)){
            Set<Map.Entry<String,String>> entrySet=map.entrySet();
            for(Map.Entry<String,String> entry:entrySet){
                String s_name=entry.getKey();
                String s_course=entry.getValue();
                if(course.equalsIgnoreCase(s_course)){
                 //   map.remove(s_name);
                    nameList.add(s_name); //collecting keys into list
                }
            }

            for(String name:nameList){
                map.remove(name); //removing from map
                System.out.println("student entry removed from map for :"+name);
            }

        }else{
            System.out.println("entries are not found for given course:"+course);
        }

    }

    private static void printMap(Map<String,String> studentCourseMap){

        Set<Map.Entry<String,String>> studentEntrySet=studentCourseMap.entrySet();

        for(Map.Entry<String,String> entry:studentEntrySet){
            String name=entry.getKey();
            String course=entry.getValue();
            System.out.println(name+"----> "+course);
        }


    }

    public static void main(String[] args) {

        Map<String,String>  studentCourseMap=new HashMap<>();
        makeAnEntry(studentCourseMap,"arun","CSE");
        makeAnEntry(studentCourseMap,"varun","IT");
        makeAnEntry(studentCourseMap,"tarun","ECE");
        makeAnEntry(studentCourseMap,"rani","IT");
        makeAnEntry(studentCourseMap,"vani","CSE");
        makeAnEntry(studentCourseMap,"pavani","ECE");
        makeAnEntry(studentCourseMap,"taruni","EEE");

        printMap(studentCourseMap);

        removeAnEntryByCourse(studentCourseMap,"CSE");

        System.out.println("===========================");
        printMap(studentCourseMap);
    }
}
