package com.persistent.apps.day.eight;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class AppOne {

    public static void main(String[] args) {

        HashMap<Integer,String>  studentMap=new HashMap<>();
        studentMap.put(1001,"arun");
        studentMap.put(1004,"charun");
        studentMap.put(1005,"varun");
        studentMap.put(1002,"varun");
        studentMap.put(1003,"tarun");
        System.out.println(studentMap);

        // print only student IDs
        Set<Integer> keys=studentMap.keySet();
        System.out.println("Student IDs is:"+keys);
        //print only student names
        Collection<String> names=studentMap.values();
        System.out.println("Student names are:"+names);

        //find one student "tarun"
            Iterator<Integer> iterator=keys.iterator();
            boolean searchStatus=false;
            while (iterator.hasNext()){
                Integer id=iterator.next();
                String name=studentMap.get(id);
                if(name.equals("karun")){
                    System.out.println("student found");
                    searchStatus=true;
                    break;
                }
            }
            if(searchStatus==false){
                System.out.println("student not found");
            }
    }
}