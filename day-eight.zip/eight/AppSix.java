package com.persistent.apps.day.eight;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AppSix {
    public static void main(String[] args) {
    //sum of even numbers
        int arr[]={1,2,3,4,5,6,7,8,9,10};
        int sum=Arrays.stream(arr).filter(n->n%2==0).reduce(0,(x,y)->x+y);
        System.out.println("sum of even is:"+sum);

        //find the names length >=5
        String names[]={"arun","varun","tarun","charun","marun"};

        List<String> nameList=Arrays.stream(names).filter(name-> name.length()>=5).collect(Collectors.toList());

        System.out.println("names length > =5  are:"+nameList);

        //find the names whose length >=5 and display in sorted order
        String nameArr[]={"vani","rani","pavani","sravani","charani","taruni","bharani"};

        List<String> sortedNames=Arrays.stream(nameArr).filter(name->name.length()>=5).sorted().collect(Collectors.toList());

        System.out.println(sortedNames);
    }
}