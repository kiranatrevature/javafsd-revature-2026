//program to implement the built-in functional interface
package com.persistent.apps.day.eight;
import java.util.function.Function;
public class AppFive {
    private static void findSquares(int arr[],Function<Integer,Integer> function){
        for(int ele:arr){
            System.out.println("square is:"+function.apply(ele));
        }
    }

    private static void findVowelCount(String arr[],Function<String,Integer> vowlerCounter){

        for(String city:arr){
            System.out.println(city+" has "+vowlerCounter.apply(city)+" vowels");
        }
    }

    public static void main(String[] args) {
        //find the squares of an array using apply function
        int arr[]={1,2,3,4,5};
        Function<Integer,Integer> function= (n)-> n*n; //implementation of apply method using Lamdba expr
        findSquares(arr,function);

        //find the vowels in each string of an array
        String cities[]={"Hyderabad","Secunderabad","Chennai","Bangalore","Mumbai","Trichy"};

        Function<String,Integer>  vowelCounter= (city)-> {
            int vowelCnt=0;
                for(int i=0;i<city.length();i++){
                    char ch=city.charAt(i);
                    if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u'){
                        vowelCnt++;
                    }
                }
                return vowelCnt;
        };

        findVowelCount(cities,vowelCounter);
    }
}