//program to implement functional interface using Lambda expression
package com.persistent.apps.day.eight;

@FunctionalInterface
interface  Greetable{
    public abstract String greet(String name);
}
public class AppThree {
    public static void main(String[] args) {
        Greetable greetable=  (name)-> {
            return "Hello "+name+" How are you?";
        };
        System.out.println(greetable.greet("Arun"));
    }
}
