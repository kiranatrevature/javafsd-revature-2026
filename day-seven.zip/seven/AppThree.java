//program to implement ArrayList to store only one type of elements
package com.persistent.apps.day.seven;

import java.util.ArrayList;
import java.util.List;

public class AppThree {

    public static void main(String[] args) {

    ArrayList<Integer> list=new ArrayList<Integer>();
    list.add(100);
    list.add(200);
    list.add(300);
    System.out.println(list);

    //add element in the beginning
        list.addFirst(500);

        //add element at the last
        list.addLast(1000);
        System.out.println(list);

        //add eleemnt in the middle
        list.add(2,700);
        System.out.println(list);

        //add multiple elements in the anywhere
        list.addAll(3, List.of(1,2,3,4));
        System.out.println(list);

        //remove element at last
        list.removeLast();
        //remove element at first
        list.removeFirst();
        System.out.println(list);
        //remove eleemnts in the middle or anywhere
        list.remove(5);
        System.out.println(list);

        //replace an element
        list.set(4,1001);
        System.out.println(list);

        //remove all elements
        list.clear();

        System.out.println(list);

//    list.add(true);
//    list.add("hello");
//    list.add('c');
//    list.add(12000.23);


    }
}
