//program to implement ArrayList collection
package com.persistent.apps.day.seven;

import java.util.ArrayList;

public class AppOne {
    static class Card{
        private int cardNo;
        private double cardLimit;

        public Card(int cardNo, double cardLimit) {
            this.cardNo = cardNo;
            this.cardLimit = cardLimit;
        }

        public int getCardNo() {
            return cardNo;
        }

        public double getCardLimit() {
            return cardLimit;
        }
    }

    public static void main(String[] args) {

        ArrayList list=new ArrayList();
        list.add(10);
        list.add("hello");
        list.add(true);
        list.add(null);
        list.add(new Card(12345,45000.25));

        System.out.println(list);
        Object obj=list.get(4);
        Card card=(Card)obj;
        System.out.println("card no:"+card.getCardNo()+" limit is:"+card.getCardLimit());

    }

}
