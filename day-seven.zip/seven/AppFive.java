package com.persistent.apps.day.seven;
import java.util.*;

class Product{

    private int id;
    private String name;
    private double price;
    private String category;
    private int quantity;
    private String manufacturer;

    public Product(int id, String name, double price, String category, int quantity,String manufacturer) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
        this.quantity = quantity;
        this.manufacturer=manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", category='" + category + '\'' +
                ", quantity=" + quantity +
                ", manufacturer='" + manufacturer + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
public class AppFive {

    private static void findNamesBetweenGivenRange(List<Product> productList,int from,int to){

        for(Product product:productList){

            String name=product.getName();
            int len=name.length();
            if(len>=from && len<=to){
                System.out.println("Product with name 3 or 5 letters is:"+name);
            }
        }

    }

    private static void findTotalPriceInGivenCategory(List<Product> productList,String category){

        Iterator<Product>  iterator=productList.iterator();
        double total=0.0;
        while(iterator.hasNext()){

            Product product=iterator.next();

            String product_category=product.getCategory();

            if(category.equalsIgnoreCase(product_category)){
                double price=product.getPrice();
                total=total+price;
            }

        }

        System.out.println("Total price of products in "+category+" is:"+total);

    }

    private static List<Product>  findProductByCategory(List<Product> productList,String category){

        List<Product> newProductList=new ArrayList<>();

        Iterator<Product> iterator =productList.iterator();

        while (iterator.hasNext()){

            Product product=iterator.next();

            String product_category=product.getCategory();

            if(category.equalsIgnoreCase(product_category)){
                newProductList.add(product);
            }

        }
        return newProductList;



    }




    public static void main(String[] args) {


        Product p1=new Product(1,"fan",2500.25,"electronics",9,"USHA");
        Product p2=new Product(3,"tv",12500.25,"electronics",10,"LG");
        Product p3=new Product(4,"mobile",7500.25,"electronics",12,"SAMSUNG");
        Product p4=new Product(2,"bottle",400.25,"plastic",22,"NAYASA");
        Product p5=new Product(5,"lunchbox",500.25,"plastic",12,"NAYASA");
        Product p6=new Product(7,"plate",3200.25,"glass",4,"Glassion");
        Product p7=new Product(6,"vase",7200.25,"glass",6,"Glassion");
        Product p8=new Product(8,"smart-phone",16000.25,"electronics",52,"SAMSUNG");

        List<Product> productList=List.of(p1,p2,p3,p4,p5,p6,p7,p8);

        // find out the names of products which are between 3 or 5 length
        findNamesBetweenGivenRange(productList,3,5);

        //find the total price of the products in given category

        findTotalPriceInGivenCategory(productList,"electronics");

        //find-out the products in given category
        List<Product> prodList=findProductByCategory(productList,"glass");

        System.out.println(prodList);


        System.out.println("----------------------------------");

        for(Product product:productList){
            System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice());
        }

        List<Integer> numList= Arrays.asList(2, 8, 4, 5, 6, 7, 1);

        System.out.println(numList);

        //arrange in ascending order
        Collections.sort(numList);
        System.out.println(numList);

        //arrange in descending order
        Collections.reverse(numList);
        System.out.println(numList);








    }
}
