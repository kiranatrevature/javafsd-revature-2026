//program to implement object ordering (natural ordering)
package com.persistent.apps.day.seven;

import java.util.*;


public class AppSix {

    static class Product implements Comparable<Product>{

        private int id;
        private String name;
        private double price;
        private String category;
        private int quantity;
        private String manufacturer;

        public Product(int id, String name, double price, String category, int quantity,String manufacturer) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.category = category;
            this.quantity = quantity;
            this.manufacturer=manufacturer;
        }

        public String getManufacturer() {
            return manufacturer;
        }

        public void setManufacturer(String manufacturer) {
            this.manufacturer = manufacturer;
        }

        @Override
        public String toString() {
            return "Product{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", price=" + price +
                    ", category='" + category + '\'' +
                    ", quantity=" + quantity +
                    ", manufacturer='" + manufacturer + '\'' +
                    '}';
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        @Override
        public int compareTo(Product p) {
            //logic to compare two products object by id or name or category or qty or price
            Product p1=this;
            Product p2=p;

            if(p1.getId()<p2.getId()){
                return -1;
            }else if(p1.getId()>p2.getId()){
                return 1;
            }else{
                return 0;
            }
        }

    }

    static class NamedComparator implements Comparator<Product>{

        @Override
        public int compare(Product o1, Product o2) {
            //logic to compare by product name
            String name1=o1.getName();
            String name2=o2.getName();
            return name1.compareTo(name2);
        }
    }

    static class NamedComparatorDesc implements Comparator<Product>{

        @Override
        public int compare(Product o1, Product o2) {
            //logic to compare by product name
            String name1=o1.getName();
            String name2=o2.getName();
            return name2.compareTo(name1);
        }
    }

    static class PriceComparatorAsc implements  Comparator<Product>{

        @Override
        public int compare(Product o1, Product o2) {

            if(o1.getPrice()<o2.getPrice()){
                return -1;
            }else if(o1.getPrice()>o2.getPrice()){
                return 1;
            }
            return 0;
        }
    }



    public static void main(String[] args) {

        Product p1=new Product(1,"fan",2500.25,"electronics",9,"USHA");
        Product p2=new Product(3,"tv",12500.25,"electronics",10,"LG");
        Product p3=new Product(4,"mobile",7500.25,"electronics",12,"SAMSUNG");
        Product p4=new Product(2,"bottle",400.25,"plastic",22,"NAYASA");
        Product p5=new Product(5,"lunchbox",500.25,"plastic",12,"NAYASA");
        Product p6=new Product(7,"plate",3200.25,"glass",4,"Glassion");
        Product p7=new Product(6,"vase",7200.25,"glass",6,"Glassion");
        Product p8=new Product(8,"smart-phone",16000.25,"electronics",52,"SAMSUNG");

        List<Product> productList=Arrays.asList(p1,p2,p3,p4,p5,p6,p7,p8);

        Collections.sort(productList);

        System.out.println("----sorted by id---");
        for(Product product:productList){
            System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice());
        }

        System.out.println("----sorted by name----");
        Collections.sort(productList,new NamedComparator());
        for(Product product:productList){
            System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice());
        }
        System.out.println("----sorted by name in desc----");
        Collections.sort(productList,new NamedComparatorDesc());
        for(Product product:productList){
            System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice());
        }
        System.out.println("----sorted by Price in Asc----");
        Collections.sort(productList,new PriceComparatorAsc());
        for(Product product:productList){
            System.out.println(product.getId()+" "+product.getName()+" "+product.getPrice());
        }



    }
}
