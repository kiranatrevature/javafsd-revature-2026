//program to implement fruits collection
package com.persistent.apps.day.seven;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppFour {

    private static void addFruit(ArrayList<String> fruitList,String fruit){
        fruitList.add(fruit);
    }
    private static void updateFruit(ArrayList<String> fruitList,String findFruit,String replaceFruit){
            int index=fruitList.indexOf(findFruit);
            fruitList.set(index,replaceFruit);
        System.out.println("fruit was repalced");
    }
    private static void addAllFruits(ArrayList<String> fruitList,String[] fruits){
        fruitList.addAll(Arrays.asList(fruits));
    }
    public static void main(String[] args) {
        ArrayList<String> fruitList=new ArrayList<>();
        addFruit(fruitList,"Apple");
        addFruit(fruitList,"Orange");
        addFruit(fruitList,"Banana");
        addFruit(fruitList,"Manago");
        System.out.println(fruitList);
        updateFruit(fruitList,"Orange","Melon");
        System.out.println(fruitList);
        addAllFruits(fruitList,new String[]{"Grapes","Gouva","Dragon"});
        System.out.println(fruitList);
    }
}