//program to implement ArrayList collection iteration
package com.persistent.apps.day.seven;

import java.util.ArrayList;

public class AppTwo {
    static class Card{
        private int cardNo;
        private double cardLimit;

        public Card(int cardNo, double cardLimit) {
            this.cardNo = cardNo;
            this.cardLimit = cardLimit;
        }

        public int getCardNo() {
            return cardNo;
        }

        public double getCardLimit() {
            return cardLimit;
        }
    }

    public static void main(String[] args) {

        ArrayList list=new ArrayList();
        list.add(10);
        list.add("hello");
        list.add(true);
        list.add(null);
        list.add(new Card(12345,45000.25));
        list.add(Integer.valueOf(10));
        list.add(Boolean.valueOf(true));

        for(int i=0;i<list.size();i++){
            if(i==4){
                Card card=(Card) list.get(i);
                System.out.println("card no  is:"+card.getCardNo()+" limit is:"+card.getCardLimit());
            }else {
                System.out.println("element is:" + list.get(i));
            }
        }

    }
}