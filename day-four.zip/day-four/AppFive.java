//program to demonstrate static variables
package com.persistent.apps.day.four;

class Pupil{
    private static String college;
    private int rollNo;
    private String name;
    private double fee;
    static{
        //initialize static variables
        college="GNI";
    }

    public Pupil(int rollNo,String name,double fee){
        this.rollNo=rollNo;
        this.name=name;
        this.fee=fee;
    }

    public int getRollNo(){return this.rollNo;}
    public String getName(){return this.name;}
    public double getFee(){return this.fee;}
    public static String getCollege(){return college;}
}
public class AppFive {

    public static void main(String[] args) {

        Pupil p1=new Pupil(1234,"arun",45000.25);
        System.out.println(p1.getRollNo()+" "+p1.getName()+" "+p1.getFee()+" "+p1.getCollege());

        Pupil p2=new Pupil(1235,"varun",55000.25);
        System.out.println(p2.getRollNo()+" "+p2.getName()+" "+p2.getFee()+" "+p2.getCollege());
    }
}