package com.persistent.apps.day.four;

class Product{
    private int id;
    private String name;
    private double price;
    private String category;

    private static int idGenerator=1001;

    public Product(String name,double price,String category){
        this.id=idGenerator++;
        this.name=name;
        this.price=price;
        this.category=category;
    }

    public String toString(){
        return this.id+" "+this.name+" "+this.price+" "+this.category;
    }

}
public class AppSeven {

    public static void main(String[] args) {

        Product p1=new Product("fan",2500.25,"electronics");
        Product p2=new Product("Tv",12500.25,"electronics");
        Product p3=new Product("mixer",3500.25,"electronics");

        System.out.println("p1 is:"+p1.toString());
        System.out.println("p2 is:"+p2.toString());
        System.out.println("p3 is:"+p3.toString());
    }
}