//program to demonstarte creation of object
package com.persistent.apps.day.four;
class Student{
    int id;
    String name;
    String branch;
}

public class AppOne {
    public static void main(String[] args) {
        Student s1=new Student(); //creating object
        s1.id=1001;
        s1.name="arun";
        s1.branch="CSE";
        System.out.println("s1-->id is:"+s1.id+" name is:"+s1.name+" branch is:"+s1.branch);

        Student s2=new Student(); //creating object
        //updating s2 object properties
        s2.id=1002;
        s2.name="varun";
        s2.branch="ECE";
        System.out.println("s2-->id is:"+s2.id+" name is:"+s2.name+" branch is:"+s2.branch);

        Student s3=s2;
        System.out.println("s3-->id is:"+s3.id+" name is:"+s3.name+" branch is:"+s3.branch);
        s3.branch="IT";
        System.out.println("s3--->id is:"+s3.id+" name is:"+s3.name+" branch is:"+s3.branch);
        System.out.println("s2-->id is:"+s2.id+" name is:"+s2.name+" branch is:"+s2.branch);
    }
}