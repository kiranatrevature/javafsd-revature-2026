//program to demonstarte the execution of static block
package com.persistent.apps.day.four;


public class AppNine {

    int a;
    int b;
    static int c;

    {
        a=100;
        b=200;
        System.out.println("non-static block is executing");
    }

    static{
        c=300;
        System.out.println("static block is executing");
    }

    public static void main(String[] args) {

        System.out.println("main method");

        //System.out.println("a is:"+a);
        //System.out.println("b is:"+b);

        AppNine obj1=new AppNine();

        AppNine obj2=new AppNine();


        AppNine obj3=new AppNine();

    }

    static{
        System.out.println("i am second static block");
    }
}
