package com.persistent.apps.day.four;

class Employ{
    int id;
    String name;
    double salary;
    public Employ(int id,String name,double salary){
        this.id=id;
        this.name=name;
        this.salary=salary;
    }
}

public class AppTwo {

    public static void main(String[] args) {

    Employ e1=new Employ(1001,"arun",45000.25);
    Employ e2=new Employ(1002,"varun",55000.25);

    System.out.println("e1--> id:"+e1.id+" name:"+e1.name+" salary is:"+e1.salary);
    System.out.println("e2--> id:"+e2.id+" name:"+e2.name+" salary is:"+e2.salary);
    }
}