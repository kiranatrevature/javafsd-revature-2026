package com.persistent.apps.day.four;
class Counter{
    int x=1; //non-static
    static  int y=1; //static
    public Counter(){
        x++;
        y++;
    }
}
public class AppSix {

    public static void main(String[] args) {
        Counter c1=new Counter();
        Counter c2=new Counter();
        Counter c3=new Counter();
        System.out.println("c1.x is:"+c1.x+" c2.x is:"+c2.x+" c3.x is:"+c3.x);

        System.out.println("c1.y is:"+c1.y+" c2.y is:"+c2.y+" c3.y is:"+c3.y);
    }
}
