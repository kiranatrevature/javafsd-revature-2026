package com.persistent.apps.day.four;

import java.util.Arrays;

class Calculator{

    public static void add(int a,int b){
        System.out.println("sum is:"+(a+b));
    }

    public static void sub(int a,int b){
        System.out.println("sub is:"+(a-b));
    }

    public static void max(int a,int b){
        if(a>b)
        System.out.println("max is:"+a);
        else
            System.out.println("max is:"+b);
    }

    public static void sort(int arr[]){
        Arrays.sort(arr);
        System.out.println("sorted array is:"+Arrays.toString(arr));
    }
}
public class AppEight {

    public static void main(String[] args) {
        Calculator.add(10,20);
        Calculator.max(120,100);
        Calculator.sort(new int[]{2,3,4,5,6});
    }
}
