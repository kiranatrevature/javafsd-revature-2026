package com.persistent.apps.day.four;

class Vehicle{
    int id;
    String brand;
    String color;
    String vType;
    String manufacturer;
    public Vehicle(){
        manufacturer="TATA";
    }
    public Vehicle(int id){
        this();
        this.id=id;
    }
    public Vehicle(int id,String brand){
        //this.id=id;
        this(id);
        this.brand=brand;
    }

    public Vehicle(int id,String brand,String color){
       // this.id=id;
       // this.brand=brand;
        this(id,brand);
        this.color=color;
    }

    public Vehicle(int id,String brand,String color,String vType){
//        this.id=id;
//        this.brand=brand;
//        this.color=color;
        this(id,brand,color);
        this.vType=vType;
    }
}
public class AppThree {
    public static void main(String[] args) {
        Vehicle v=new Vehicle(1234,"BMW","white");
        System.out.println(v.id+" "+v.brand+" "+v.color+" "+v.vType);
    }
}