//program to demonstrate the need for encapsulation
package com.persistent.apps.day.four;

class Account{
    //private modifier
    private long accountNo;
    private String accountHolder;
    private int accountHolderAge;
    private double balance;
    private String ifsc;

    //accessor methods: setter and getter methods
    public void setAccountNo(long accountNo){
        if(accountNo<0){
            throw new IllegalArgumentException("accountNo is not valid!");
        }
        this.accountNo=accountNo;
    }
    public void setAccountHolder(String accountHolder){
        this.accountHolder=accountHolder;
    }

    public void setAccountHolderAge(int accountHolderAge){
        if(accountHolderAge<18 | accountHolderAge>70){
            throw new IllegalArgumentException("age must between 18  to 70 only");
        }
        this.accountHolderAge=accountHolderAge;
    }

    public void setBalance(double balance){
        if(balance<0){
            throw new IllegalArgumentException("balance must not be negative!");
        }
        this.balance=balance;
    }
    public void setIfsc(String ifsc){
        this.ifsc=ifsc;
    }
    
    public long getAccountNo(){
        return this.accountNo;
    }
    
    public String getAccountHolder(){
        return this.accountHolder;
    }

    public double getBalance(){
        return this.balance;
    }

    public int getAccountHolderAge(){
        return this.accountHolderAge;
    }
}
public class AppFour {

    public static void main(String[] args) {

        Account account=new Account();
      //  account.accountNo=-12345;
        account.setAccountNo(-12345);
        //account.accountHolderAge=260;
        account.setAccountHolderAge(260);
        //account.accountHolder="varun";
        account.setAccountHolder("varun");
        //account.balance=-405000.25;
        account.setBalance(-405000.25);
        //account.ifsc="SBI1234";
        account.setIfsc("SBI1234");

        //System.out.println("account no:"+account.accountNo);
        System.out.println("account no:"+account.getAccountNo());
        //System.out.println("holder is:"+account.accountHolder);
        System.out.println("holder is:"+account.getAccountHolder());
        //System.out.println("balance is:"+account.balance);
        System.out.println("balance is:"+account.getBalance());
        //System.out.println("holder age is:"+account.accountHolderAge);
        System.out.println("age is:"+account.getAccountHolderAge());

    }
}