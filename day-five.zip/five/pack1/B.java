package com.persistent.apps.day.five.pack1;

public class B {

    public static void main(String[] args) {

        A obj=new A();

        System.out.println("public x of A is:"+obj.x);
        System.out.println("protected y of A is:"+obj.y);
        System.out.println("default z of A is:"+obj.z);
        //System.out.println("k of A is:"+obj.k);

    }

}
