package com.persistent.apps.day.five.pack1;

public class C extends A{

    public static void main(String[] args) {

        C obj=new C();
        System.out.println("x of A is:"+obj.x);
        System.out.println("y of A is:"+obj.y);
        System.out.println("z of A is:"+obj.z);
        //System.out.println("k of A is:"+obj.k);


    }


}
