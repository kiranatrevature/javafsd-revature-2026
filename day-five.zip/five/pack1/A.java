package com.persistent.apps.day.five.pack1;

public class A {

    public int x=10;
    protected int y=20;
    int z=30; //default
    private int k=40;

}
