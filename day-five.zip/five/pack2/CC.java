package com.persistent.apps.day.five.pack2;

import com.persistent.apps.day.five.pack1.A;

public class CC  extends A {
    public static void main(String[] args) {

        CC obj=new CC();
        //A obj=new A();

        System.out.println("x of A is:"+obj.x); // x is public
        System.out.println("y of A is:"+obj.y); // y is protected
//        System.out.println("z of A is:"+obj.z); //z is default
//        System.out.println("k of A is:"+obj.k); // k is private

    }
}
