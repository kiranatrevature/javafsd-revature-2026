package com.persistent.apps.day.five.pack2;

import com.persistent.apps.day.five.pack1.A;

public class BB {

    public static void main(String[] args) {

        A obj=new A();

        System.out.println("x of A is:"+obj.x);
//        System.out.println("y of A is:"+obj.y);
//        System.out.println("z of A is:"+obj.z);
//        System.out.println("k of A is:"+obj.k);


    }
}
