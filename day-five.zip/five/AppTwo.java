//program to implement is-a relation and using super keyword to refer to parent class property and method
package com.persistent.apps.day.five;

class SBI{
    private double roi=3.0;
    public double calculateInterest(double amount,int years){
            double interest=(amount*years*roi)/100;
            return interest;
    }
    public double getRoi(){
        return  this.roi;
    }
}

class SBH extends SBI{
     //SBH wants to provide 1% morethan what SBI offer
     //double roi=super.roi+1; //super is used here to refer the parent class property
    double roi=super.getRoi()+1; // super is used to refer the parent class method

    @Override
    public double calculateInterest(double amount,int years){
        double interest=(amount*years*roi)/100;
        return interest;
    }

}

class SBT extends SBI{

    //SBT wants to provide 1.5% morethan what SBI offer
    //double roi=super.roi+1.5; // here , super is refering to parent class property
    double roi=super.getRoi()+1.5; //here, super is refering to the parent class method

    @Override
    public double calculateInterest(double amount,int years){

        double interest=(amount*years*roi)/100;
        return interest;
    }
}

public class AppTwo {

    public static void main(String[] args) {

        SBI sbi=new SBI();
        double roi=sbi.calculateInterest(24000,4);

        System.out.println("SBI roi is:"+roi);

        SBH sbh=new SBH();
        roi=sbh.calculateInterest(24000,4);
        System.out.println("SBH roi is:"+roi);
        SBT sbt=new SBT();
        roi=sbt.calculateInterest(24000,4);
        System.out.println("SBT roi is:"+roi);
    }
}
