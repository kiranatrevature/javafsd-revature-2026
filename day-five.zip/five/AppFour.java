package com.persistent.apps.day.five;

class Engine{
    boolean engineStatus;
    public void startEngine(){
        engineStatus=true;
        System.out.println("Engine started");
        }
    public void stopEngine(){
        engineStatus=false;
        System.out.println("Engine stopped");
    }

    public boolean findEngineStatus(){
        return this.engineStatus;
    }
}

class MyCar{
    Engine engine=new Engine();

    public void startCar(){
        engine.startEngine();
        if(engine.findEngineStatus()){
            System.out.println("car started");
        }
    }

    public void stopCar(){
        engine.stopEngine();
        if(engine.findEngineStatus()==false){
            System.out.println("car stopped");
        }
    }

}

public class AppFour {

    public static void main(String[] args) {

        MyCar m=new MyCar();
        m.startCar();
        m.stopCar();
    }

}
