//program to impl method overloading
package com.persistent.apps.day.five;

class Customer{
    private int id;
    private String name;
    public String custType;
    public Customer(int id,String name,String custType){
        this.id=id;
        this.name=name;
        this.custType=custType;
    }

    public String getName() {
        return name;
    }

    public String getCustType() {
        return custType;
    }
}

class CustomerCare{

    static void handleCustomer(String name,int time){
        System.out.println("handling call with "+name+" and time spent is:"+time+" min");
    }
    static void handleCustomer(String name,int time,String mail){
        System.out.println("handling call with "+name+" and time spent is:"+time+" mail to send:"+mail);

    }
    static void handleCustomer(String name,int time,String mail, String phone){
        System.out.println("handling call with "+name+" and time spent is:"+time+" mail to send:"+mail+" phone to dial:"+phone);
    }


    static void makeCall(Customer customer){
            String custType=customer.getCustType();
            if(custType.equals("standard")){
            handleCustomer(customer.getName(),3);
            }else if(custType.equals("golden")){
                handleCustomer(customer.getName(),5,customer.getName()+"@yahoo.com");
            }else if(custType.equals("platinum")){
                handleCustomer(customer.getName(),8,customer.getName()+"@gmail.com","044-123456");
            }

    }


}

public class AppSeven {

    public static void main(String[] args) {

        Customer customer=new Customer(1001,"arun","platinum");
        CustomerCare.makeCall(customer);

    }
}
