//program to demonstrate the implementation of is-a relationship in java
package com.persistent.apps.day.five;

class Vehicle{
    private String color;
    private int speed;

    public Vehicle(String color,int speed){
        this.color=color;
        this.speed=speed;
    }
    public void start(){
        System.out.println("vehicle started");
    }
    public void stop(){
        System.out.println("vehicle stopped");
    }
}

class Car extends Vehicle{
    private int seatingCapacity;
    private int doors;
    public Car(String color,int speed,int seatingCapacity,int doors){
    super(color,speed); //using super() constructor to invoke parent class constructor
    this.seatingCapacity=seatingCapacity;
    this.doors=doors;
    }

    public void accelerate(){
        System.out.println("acclerate car");
    }

}


public class AppOne {

    public static void main(String[] args) {

        Car car=new Car("white",120,6,4);
        car.start();
        car.accelerate();
        car.stop();
    }
}
