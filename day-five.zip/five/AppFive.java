//program to implement the abstract class and its child classes
package com.persistent.apps.day.five;
abstract class Shape{
    abstract void draw();
    abstract void paint();
}

class Rectangle extends Shape{

    @Override
    void draw() {
        System.out.println("drawing Rectangle");
    }

    @Override
    void paint() {
        System.out.println("painting Rectangle");
    }
}

class Triangle extends Shape{

    @Override
    void draw() {
        System.out.println("drawing Triangle");
    }

    @Override
    void paint() {
        System.out.println("painting Triangle");
    }
}

public class AppFive {

    public static void main(String[] args) {

        Shape shape;
        shape=new Rectangle();
        shape.draw();
        shape.paint();
        System.out.println("----------------------");
        shape=new Triangle();
        shape.draw();
        shape.paint();
    }
}
