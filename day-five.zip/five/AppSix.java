package com.persistent.apps.day.five;

interface  Animal{
    void eat();
    void sleep();
    void move();
}

abstract class AbstractAnimal implements Animal{
    String name;
    String food;
    String lives;
    public AbstractAnimal(String name,String food,String lives){
        this.name=name;
        this.food=food;
        this.lives=lives;
    }
    @Override
    public void eat() {
        System.out.println(name+" eats "+food);
    }

    @Override
    public void sleep() {
        System.out.println(name+"  live in "+lives);
    }
}

class Dog extends AbstractAnimal{

    public Dog(String name,String food,String lives){
        super(name,food,lives);
    }

    @Override
    public void move() {
        System.out.println("dog moves on legs");
    }
}
class Fish extends AbstractAnimal{

    public Fish(String name,String food,String lives){
        super(name,food,lives);
    }

    @Override
    public void move() {
        System.out.println("fish swims to move");
    }
}
class Bird extends AbstractAnimal{

    public Bird(String name,String food,String lives){
        super(name,food,lives);
     }

    @Override
    public void move() {
        System.out.println("bird flies on wings");
    }
}
public class AppSix {

    public static void main(String[] args) {

        Bird b=new Bird("cokoo","nuts","Nest");
        b.eat();
        b.move();
        b.sleep();
    }
}