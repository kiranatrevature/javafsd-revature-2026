package com.persistent.apps.day.nine;

class PrintThread implements  Runnable{
    @Override
    public void run() {
        for(int i=1;i<=10;i=i+2){
            System.out.println("element is:"+i);
            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
public class AppFour {
    public static void main(String[] args) {
        PrintThread pt=new PrintThread();
        //pt.start();
        Thread thread=new Thread(pt); // passing Runnable obj to Thread class constructor
        thread.start();
    }
}