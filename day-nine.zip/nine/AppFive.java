//program to implement how multiple threads run
package com.persistent.apps.day.nine;
class ThreadOne extends Thread{
    public void run(){
        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println("ThreadOne - " + i);
                Thread.sleep(100);
            }
        }catch (InterruptedException ie){
            System.out.println("exception is:"+ie.getMessage());
        }
    }

}
class ThreadTwo extends Thread{
    public void run(){
        try {
            for (int i = 10; i >= 6; i--) {
                System.out.println("ThreadTwo - " + i);
                Thread.sleep(200);
            }
        }catch (InterruptedException ie){
            System.out.println("exception is:"+ie.getMessage());
        }
    }

}
public class AppFive {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("main begins");
        ThreadOne t1=new ThreadOne();
        ThreadTwo t2=new ThreadTwo();
        t1.start();
        t2.start();

        t1.join(); // t1 asks main to wait
        t2.join(); // t2 asks main to wait

        System.out.println("main ends");
    }
}