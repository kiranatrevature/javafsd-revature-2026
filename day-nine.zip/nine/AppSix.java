package com.persistent.apps.day.nine;

import java.util.stream.IntStream;

class Theater extends Thread{

    String customer;

    int tickets[]= IntStream.range(12341,12351).toArray();
    int currentTicket=0;

    public Theater(String customer){
        this.customer=customer;
    }

    public void issueTicket(){
        System.out.println(customer+" issuing ticket :"+tickets[currentTicket]);
    }

    public void cutTicket(){
        System.out.println(customer+" cutting ticket:"+tickets[currentTicket]);

    }

    public void showSeat(){
        System.out.println(customer+" showing seat for ticket:"+tickets[currentTicket]);
    }

    public void run(){
            issueTicket();
            cutTicket();
            showSeat();
    }
}

public class AppSix {

    public static void main(String[] args) {

        for(int i=1;i<=5;i++) {
            Theater t = new Theater("customer-"+i);
            t.start();
        }


    }
}
