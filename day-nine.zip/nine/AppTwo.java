package com.persistent.apps.day.nine;

public class AppTwo {

    public static void main(String[] args) {

        Thread thread=Thread.currentThread();
        System.out.println("Thread name is:"+thread.getName());
        System.out.println("Thread priority is:"+thread.getPriority());
        System.out.println("Thread group is:"+thread.getThreadGroup().getName());
        System.out.println("Thread id is:"+thread.getId());
        System.out.println("Thread state is:"+thread.getState().name());
        System.out.println("------------------------------------");
        thread.setName("MainCurrent");
        thread.setPriority(Thread.MAX_PRIORITY);
        //thread.setDaemon(true);
        System.out.println("Thread name is:"+thread.getName());
        System.out.println("Thread priority is:"+thread.getPriority());
        System.out.println("Thread group is:"+thread.getThreadGroup().getName());
        System.out.println("Thread id is:"+thread.getId());
        System.out.println("Thread state is:"+thread.getState().name());
    }
}
