//program to implement data processing using streams on collections
package com.persistent.apps.day.nine;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Student{
    private int id;
    private String name;
    private double fee;
    private String branch;

    public Student(int id, String name, double fee, String branch) {
        this.id = id;
        this.name = name;
        this.fee = fee;
        this.branch = branch;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", fee=" + fee +
                ", branch='" + branch + '\'' +
                '}';
    }
}

public class AppOne {

    private static List<Student> findStudentsByBranch(List<Student> studentList,String branch){


        return studentList.stream().filter(st->st.getBranch().equalsIgnoreCase(branch)).collect(Collectors.toList());
//        Stream<Student> studentStream=studentList.stream();
//        Stream<Student> filteredStudentStream=studentStream.filter(student -> student.getBranch().equalsIgnoreCase(branch));
//        List<Student> newList=filteredStudentStream.collect(Collectors.toList());
//        return newList;


//        List<Student> newList=new ArrayList<>();
//        //iterate over the list
//        for(Student student:studentList){
//            String s_branch=student.getBranch();
//            if(branch.equalsIgnoreCase(s_branch)){
//            newList.add(student);
//            }
//        }
//        return newList;
    }

    private static void findFeeDetailsPaidByBranch(List<Student> studentList,String branch){

       double total_fee= studentList.stream().filter(st->st.getBranch().equalsIgnoreCase(branch)).map(st->st.getFee()).reduce(0.0,(f1,f2)->f1+f2);

//        for(Student student:studentList){
//            String s_branch=student.getBranch();
//            if(branch.equalsIgnoreCase(s_branch)){
//                double s_fee=student.getFee();
//                total_fee=total_fee+s_fee;
//            }
//        }
        System.out.println("Total fee paid by "+branch+" is:"+total_fee);

    }

    private static void  findStudentNamesByBranch(List<Student> studentList,String branch){

        System.out.println("----student names in "+branch+"-----------");

        studentList.stream()
                    .filter(st->st.getBranch().equals(branch))
                    .map(st->st.getName())
                    .collect(Collectors.toList())
                    .forEach(name->System.out.println(branch+" has "+name));

//        List<String> snames=studentList.stream().filter(st->st.getBranch().equals(branch)).map(st->st.getName()).collect(Collectors.toList());
//        snames.forEach(name->System.out.println(name));


//        for(Student student:studentList){
//            String s_branch=student.getBranch();
//            if(s_branch.equalsIgnoreCase(branch)){
//                String sname=student.getName();
//                System.out.println("Student name is:"+sname);
//            }
//        }

    }

    private static  void findMaxFeePaidByBranch(List<Student> studentList,String branch){

        double maxFee=studentList.stream().filter(st->st.getBranch().equals(branch)).mapToDouble(st->st.getFee()).max().getAsDouble();

        System.out.println("max fee paid by "+branch+" is:"+maxFee);

    }

    public static void main(String[] args) {

        Student s1=new Student(100,"arun",4500.25,"CSE");
        Student s2=new Student(107,"varun",7500.25,"IT");
        Student s3=new Student(105,"tarun",6500.25,"CSE");
        Student s4=new Student(106,"karun",8500.25,"EEE");
        Student s5=new Student(104,"marun",9500.25,"EEE");
        Student s6=new Student(103,"sarun",9500.25,"IT");
        Student s7=new Student(102,"charun",12500.25,"CSE");

        List<Student> studentList= List.of(s1,s2,s3,s4,s5,s6,s7);

        // find the students in EEE dept
        List<Student> studentListByBranch=findStudentsByBranch(studentList,"EEE");
        studentListByBranch.forEach(st->System.out.println(st));

        //find the fee paid by CSE students
        findFeeDetailsPaidByBranch(studentList,"CSE");

        //find the student names in CSE branch
        findStudentNamesByBranch(studentList,"CSE");

        //find the max fee paid in CSE dept
        findMaxFeePaidByBranch(studentList,"CSE");

        //find the min fee paid in IT dept

        //find the max fee paid by whom overall

        //find the min fee paid by whom overall

        //sort the student detail by fee in desc

        //sort the student details by dept in asc



    }

}
