package com.persistent.apps.day.nine;

class MyThread extends Thread{
    @Override
    public void run() {
            for(int i=1;i<=10;i++){
                System.out.println("Number is:"+i);
                try {
                    Thread.sleep(400);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
    }
}
public class AppThree {
    public static void main(String[] args) {
        MyThread t1=new MyThread();
        t1.start();
    }
}
