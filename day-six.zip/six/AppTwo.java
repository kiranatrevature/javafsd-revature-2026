package com.persistent.apps.day.six;

interface  IAnimal{
     void eat();
     void move();
     void sleep();
}

abstract class AbstractAnimal implements IAnimal{
    private String name;
    private String food;
    private String livesIn;
    public AbstractAnimal(String name, String food,String livesIn) {
        this.name = name;
        this.food = food;
        this.livesIn=livesIn;
    }

    @Override
    public void eat() {
        System.out.println(name+" eats "+food);
    }

    @Override
    public void sleep() {
        System.out.println(name+" sleeps "+livesIn);
    }

    public String getName() {
        return name;
    }

    public String getFood() {
        return food;
    }

    public String getLivesIn() {
        return livesIn;
    }
}

class Dogg extends AbstractAnimal{

    public Dogg(String name,String food,String lives){
        super(name,food,lives);
    }

    @Override
    public void move() {
        System.out.println("dog walks on legs");
    }

    public void  play(){
        System.out.println("dog plays with kids");
    }
}
class Snake extends AbstractAnimal{

    public Snake(String name, String food, String livesIn) {
        super(name, food, livesIn);
    }

    @Override
    public void move() {
        System.out.println("snake crawls on the ground");
    }


}

class Bird extends AbstractAnimal{

    public Bird(String name, String food, String livesIn) {
        super(name, food, livesIn);
    }

    @Override
    public void move() {
        System.out.println("bird flies in the sky");
    }


    public void sing(){
        System.out.println("bird singing a song");
    }


}

class ZooTrainer{
//    public static void train(Dogg dog){
//        System.out.println("trainer giving training to :"+dog.getName());
//        dog.move();
//        System.out.println("trainer completed training to :"+dog.getName());
//    }
//
//    public static void train(Snake snake){
//        System.out.println("trainer giving training to :"+snake.getName());
//        snake.move();
//        System.out.println("trainer completed training to :"+snake.getName());
//    }
//
//
//    public static void train(Bird bird) {
//        System.out.println("trainer giving training to :" + bird.getName());
//        bird.move();
//        System.out.println("trainer completed training to :" + bird.getName());
//    }


    public static void train(IAnimal animal){

        //System.out.println("Trainer giving training to :"+animal.getName());
        animal.move();  // dynamic method dispatch
        if(animal instanceof Bird) {
            Bird bird=(Bird)animal; // down-casting or narrowing
            bird.sing();
        }
        if(animal instanceof Dogg){
            Dogg dog=(Dogg)animal; //down-casting
            dog.play();
        }

    }
}
public class AppTwo {

    public static void main(String[] args) {

    Dogg dog=new Dogg("Puppy","biscuits","den");
    Snake snake=new Snake("Snakey","snake-food","Holes");
    Bird bird=new Bird("Birdy","nuts","Nests");
    ZooTrainer.train(dog);

   // ZooTrainer.train(snake);

    //ZooTrainer.train(bird);

    }

}
