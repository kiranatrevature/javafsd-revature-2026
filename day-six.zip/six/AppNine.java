//program to implement use of throws clause
package com.persistent.apps.day.six;

public class AppNine {

    private static void method3() throws ClassNotFoundException {
            throw new ClassNotFoundException("just throwing exception");
    }
    private static void method2() throws ClassNotFoundException{
            method3();
    }

    private static void method1() throws ClassNotFoundException {
            method2();
    }

    public static void main(String[] args) throws ClassNotFoundException{

        System.out.println("main begins");
            method1();
        System.out.println("main ends");
    }
}