// program to implement try-with-catch-has-multiple exception classes
package com.persistent.apps.day.six;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AppFive {

    private static void method3(){
        Scanner scanner = new Scanner(System.in);
        int a, b, c;
        System.out.println("Enter any number:");
        a = scanner.nextInt();
        System.out.println("Enter another:");
        b = scanner.nextInt();

        c = a / b;
        System.out.println("division is:" + c);

        scanner.close();

    }
    private static void method2(){
        method3();
    }

    private static void method1(){
        method2();
    }

    public static void main(String[] args) {
        System.out.println("main begins");
        try {
            method1();
        }catch (ArithmeticException | InputMismatchException e){
            System.out.println("exception: number must be non-zero");
        }
        System.out.println("main ends");
    }
}