package com.persistent.apps.day.six;

class Account{
    private long accountNo;
    private String holderName;
    private int age;
    private double balance;
    private String accountType;

    public Account(long accountNo, String holderName, int age, double balance, String accountType) {
        this.accountNo = accountNo;
        this.holderName = holderName;
        this.age = age;
        this.balance = balance;
        this.accountType = accountType;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}

class Bank {

    public static Account createAccount(long accountNo, String holderName, int age, double balance, String accountType) {

        try {
            if (accountNo < 0) {
                throw new IllegalArgumentException("AccountNo must be non-negative");
            }
            if (holderName == null || holderName.equals("")) {
                throw new IllegalArgumentException("Account Holder name must be given");
            }
            if (age < 18 || age > 120) {
                throw new IllegalArgumentException("Age must be between 18 to 120");
            }

            return new Account(accountNo, holderName, age, balance, accountType);
        } catch (IllegalArgumentException iae) {
            System.out.println("Exception: " + iae.getMessage());
                throw iae; //re-throwing the exception object
        }

    }
}

public class AppEight {

    public static void main(String[] args) {

        try {
            Account account = Bank.createAccount(-122344, "arun", 22, 4500.25, "savings");

            if (account != null) {
                System.out.println("Account created successfully!");
            } else {
                System.out.println("Account not created");
            }
        }catch (IllegalArgumentException iae){
            System.out.println("from main, exception is:"+iae.getMessage());
        }
    }
}
