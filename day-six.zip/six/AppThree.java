// program to implement try-catch block for handling exceptions
package com.persistent.apps.day.six;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AppThree {

    private static void method3(){

        Scanner scanner=null;
        try {
            scanner = new Scanner(System.in);
            int a, b, c;
            System.out.println("Enter any number:");
            a = scanner.nextInt();
            System.out.println("Enter another:");
            b = scanner.nextInt();

            c = a / b;
            System.out.println("division is:" + c);

            System.out.println("end of method3");
        }catch(InputMismatchException e){
            System.out.println("exception is:"+e.getMessage());
        }finally {
            scanner.close(); // close the resource or scanner obj
        }

    }
    private static void method2(){
        method3();
    }

    private static void method1(){
        method2();
    }

    public static void main(String[] args) {
        System.out.println("main begins");
            method1();
        System.out.println("main ends");
    }
}