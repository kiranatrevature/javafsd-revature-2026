package com.persistent.apps.day.six;

class DemoApp{

    public void method1(){
        System.out.println("method1 begins");
        try{
            throw new ArithmeticException("divide by zero");
        }catch (ArithmeticException ae){
            System.out.println("exception is:"+ae.getMessage());
        }finally{
            System.out.println("finally in method1");
        }
        System.out.println("method1 ends");
    }

    public void method2(){
        System.out.println("method2 begins");
        try{

        }catch (ArithmeticException ae){
            System.out.println("exception is:"+ae.getMessage());
        }finally{
            System.out.println("finally in method1");
        }
        System.out.println("method2 ends");
    }

    public void method3(){
        System.out.println("method3 begins");
        try{
            return;
        }catch (ArithmeticException ae){
            System.out.println("exception is:"+ae.getMessage());
        }finally{
            System.out.println("finally in method1");
        }
        System.out.println("method3 ends");
    }

}
public class AppTen {

    public static void main(String[] args) {

        DemoApp obj=new DemoApp();
        obj.method1();
        System.out.println("-----------------------");
        obj.method2();
        System.out.println("-----------------------");
        obj.method3();
    }
}