// program to implement handling NullPointerException
package com.persistent.apps.day.six;

class HelloWorld{
    public void findLength(String name){
        name=name.trim();
        System.out.println(name+" has "+name.length()+" letters");
    }
}
public class AppSix {

    static HelloWorld helloWorld;

    public static void main(String[] args) {

            System.out.println("main begins");
            try {
                helloWorld.findLength(" arun kumar");
            } catch (NullPointerException npe) {
                System.out.println("helloWorld has null instead of instance");
            }
         System.out.println("main ends");
    }
}