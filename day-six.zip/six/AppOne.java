//program to implement the method overriding
package com.persistent.apps.day.six;
class Animal{
    public void sound(){
        System.out.println("animal makes sound");
    }
}
class Dog extends Animal{

    @Override
    public void sound(){
        System.out.println("dog barks");
    }
}
class Lion extends Animal{
    @Override
    public void sound(){
        System.out.println("lion roars");
    }
}

public class AppOne {

    public static void main(String[] args) {
            Animal animal=new Animal();
            animal.sound();

            animal=new Dog();
            animal.sound();

            animal=new Lion();
            animal.sound();
    }
}
