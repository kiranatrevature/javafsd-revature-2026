package com.persistent.apps.day.six;

class NotEligibleException extends RuntimeException{
    private String msg;
    public NotEligibleException(String msg){
        this.msg=msg;
    }

    public String toString(){
        return this.msg;
    }
}

class SIR{
        public boolean isEligibleToVote(int age){
            if(age<18){
                throw new NotEligibleException("Age is not sufficient to Vote!");
            }
            return true;
        }
}
public class AppTwelve {

    public static void main(String[] args) {

        try {
            SIR sir = new SIR();
            if(sir.isEligibleToVote(15)){
                System.out.println("Eligible to vote");
            }else{
                System.out.println("Not eligible to vote");
            }

        }catch (NotEligibleException nee){
            System.out.println("exception is:"+nee);
        }
    }
}
