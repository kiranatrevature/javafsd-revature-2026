//program to implement handle any exception using single catch and Excetpion class
package com.persistent.apps.day.six;

public class AppSeven {

    private static void method1(String name){

        if(name==null){
            throw new NullPointerException("name must not be null");
        }else if(name.length()<5){
            throw new IllegalArgumentException("name must be atleast 5 letters");
        }else if(name.contains("123")){
            throw new IllegalStateException("name must not contains digits");
        }
        System.out.println("your name is:"+name);
    }

    public static void main(String[] args) {

        try {
            //method1("ab123545");
            method1(null);
        }catch(Exception e){
            System.out.println("exception is:"+e.getMessage());
        }
//        }catch (NullPointerException e){
//            System.out.println("exception is:"+e.getMessage());
//        }catch (IllegalArgumentException e){
//            System.out.println("exception is:"+e.getMessage());
//        }catch (IllegalStateException e){
//            System.out.println("exception is:"+e.getMessage());
//        }
    }
}