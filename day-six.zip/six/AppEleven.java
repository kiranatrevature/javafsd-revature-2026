package com.persistent.apps.day.six;

class Person{
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
public class AppEleven {

    public static void main(String[] args) {

        Person p=new Person("arun",22);

        System.out.println(p);
    }
}
