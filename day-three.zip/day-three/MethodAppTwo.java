package com.persistent.apps.day.three;

class First{
    int x;
}

class Second {
    int y;
}

public class MethodAppTwo {
    static void swap(First f,Second s ){
        Integer t=f.x;
        f.x=s.y;
        s.y=t;
    }

    public static void main(String[] args) {

        First f=new First();
        f.x=10;
        Second s=new Second();
        s.y=20;

        System.out.println("before swap, a is:"+f.x+" b is:"+s.y);
        swap(f,s);
        System.out.println("after swap, a is:"+f.x+" b is:"+s.y);
    }
}