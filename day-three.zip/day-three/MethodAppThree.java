package com.persistent.apps.day.three;

import java.lang.reflect.Array;
import java.util.Arrays;

public class MethodAppThree {

    private static void reverse(int a[]){
        int start=0;
        int end=a.length-1;
        while(start<end){
            int t=a[start];
            a[start]=a[end];
            a[end]=t;
            start++;
            end--;
        }
    }

    private static void multiplyEachEleofArrayByN(int arr[],int n){
        for(int i=0;i<arr.length;i++){
            arr[i]=arr[i]*n;
        }
    }

    public static void main(String[] args) {

        int arr[]={1,2,3,4,5,6,7,8};
        System.out.println("before reverse, array is:"+ Arrays.toString(arr));
        reverse(arr);
        System.out.println("after reverse, array is:"+Arrays.toString(arr));
        int n=3;
        multiplyEachEleofArrayByN(arr,n);
        System.out.println("after multiply, array is:"+ Arrays.toString(arr));
    }
}