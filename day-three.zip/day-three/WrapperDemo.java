package com.persistent.apps.day.three;

public class WrapperDemo {
    private static boolean verifyPin(int pin){
        //if pin is having 4 digits , is valid
        if(pin<0){
            return false;
        }
        int cnt=0;
        while(pin>0){
            pin=pin/10;
            cnt++;
        }
        return cnt==4?true:false;
    }

    private static void hdfcATM(Integer pin){

        int p=pin.intValue(); // un-boxing

        if(verifyPin(p)){
            System.out.println("pin verification is success");
        }else{
            System.out.println("pin verification is failed");
        }
    }

    public static void main(String[] args) {

        //int atmPin=4567;
        String atmPin="4567";
        Integer details=Integer.valueOf(atmPin);   //boxing
        hdfcATM(details);
    }
}