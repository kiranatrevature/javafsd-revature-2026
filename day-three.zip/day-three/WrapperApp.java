package com.persistent.apps.day.three;

public class WrapperApp {
    public static void main(String[] args) {

        int x=100;
        Integer i=Integer.valueOf(x); //boxing

        int y=i.intValue(); //un-boxing
        System.out.println("y is:"+y);

        String info="employ id is:"+i.toString(); //integer to string

        System.out.println(info);


        //Auto-boxing
        int k=120;
        Integer j=Integer.valueOf(k);//boxing
        Integer m=k*10; //auto-boxing

        //Auto-unboxing
        int s=m;
        System.out.println("s is:"+s);

        Byte i1=12;
        Byte i2=12;
        System.out.println(i1==i2);

        byte b=124;
        Byte i3=Byte.valueOf(b);
        Byte i4=124;
        System.out.println("i3==i4:"+(i3==i4));

        Byte i5=Byte.valueOf(b);
        Byte i6=Byte.valueOf(b);
        System.out.println("i5==i6:"+(i5==i6));
    }
}