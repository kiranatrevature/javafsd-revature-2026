package com.persistent.apps.day.three;

class HelloWorld{
    static void method1(){
        System.out.println("i am static method");
    }
    void method2(){
        System.out.println("i am non-static method");
    }
}
public class MethodApp {

    public static void main(String[] args) {
       // method1(); //static method called directly from main, main is also static
        //method2(); //non-static method cannot be called directly from main,

        MethodApp obj=new MethodApp();
        //obj.method2(); //non-static method can be called using only by object

        HelloWorld.method1();
        //HelloWorld.method2();
        new HelloWorld().method2();
    }
}
