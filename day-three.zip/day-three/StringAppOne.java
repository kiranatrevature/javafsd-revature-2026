package com.persistent.apps.day.three;

public class StringAppOne {

    public static void main(String[] args) {
        String s1="manasa";

        String s2=new String("Sirini");

        String s3=new String("Sirini");

        System.out.println(s1==s2);
        System.out.println(s2==s3);
        System.out.println(s2.equals(s3));

        int idx=s1.indexOf('s');

        System.out.println("index of s is:"+idx);

        char ch=s1.charAt(3);

        System.out.println("char at 3rd index is:"+ch);

        System.out.println("s1 to upper case:"+s1.toUpperCase());

        System.out.println("s1 is:"+s1);

        s1.concat("yalla");
        System.out.println("s1 is:"+s1);


        String sub=s1.substring(2,4);

        System.out.println("sub of s1 is:"+sub);

        String sub2=s2.substring(3);

        System.out.println("sub of s2 is:"+sub2);

        String s4="All that glitters is not Gold";

        if(s4.contains("glitters")){
            String parts[]=s4.split("\\s");
            System.out.println("tokens in s4 are:"+parts.length);
            System.out.println("yes found");
        }else{
            System.out.println("not found");
        }

        int index=s4.indexOf("glitters");

        System.out.println("index of glitters is:"+index);
        String s=s4.substring(index,index+9);
        System.out.println("found is:"+s);

    }
}
